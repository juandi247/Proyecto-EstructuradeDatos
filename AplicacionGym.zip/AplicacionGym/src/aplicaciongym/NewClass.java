/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aplicaciongym;

import java.util.Calendar;
/**
 *
 * @author win10
 */
public class NewClass {
    public static void main(String[] args){
    Calendar calendario=Calendar.getInstance();
    int dia= calendario.get(Calendar.DAY_OF_WEEK);
    System.out.print(dia);
    System.out.println(VasHoy("si"));
    
}
public static boolean VasHoy(String coso) {
    boolean x;

    if (coso.equals("si")) {
        System.out.println("Hoy vas al gimnasio");
        x = true;
    } else {
        System.out.println("Hoy no vas al gimnasio");
        x = false;
    }
    
    return x;
  
}


}