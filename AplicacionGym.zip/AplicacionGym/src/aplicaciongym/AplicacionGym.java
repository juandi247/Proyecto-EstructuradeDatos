/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aplicaciongym;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.Calendar;

/**
 *
 * @author win10
 */
public class AplicacionGym {

  public static void Rutinacas(String rutina,String Dia ){ 
    switch (rutina) {
        case "Full body":

            rutinaFullBody();

            break;
        case "Tren Superior e inferior":
          if (Dia=="lunes" || Dia=="miercoles" ||Dia=="viernes" || Dia=="sabado"){
             rutinaTrenSuperiorInferior("lunes");
          }
          else if ("domingo".equals(Dia)||  Dia=="martes" || Dia=="jueves"){
          rutinaTrenSuperiorInferior("martes");
          }       
                      
                  
            // Lógica para la rutina Tren Superior e inferior
            break;
        case "Push pull legs":
            
            if (Dia=="lunes" || Dia=="jueves"){
                rutinaPushPullLegs("lunes");}
                else if( Dia=="martes" || Dia=="viernes"){
                    rutinaPushPullLegs("martes")  ;          
                        } 
                else if( Dia=="domingo"){
                    rutinaPushPullLegs("domingo") ;
                
                }
            
            break;
        default:
            System.out.println("Rutina no especificada.");
            break;
    }
  }
    public static void rutinaFullBody() {

        System.out.println("Rutina Full Body para un día:");
        System.out.println("Ejercicios:");
        System.out.println("- Sentadillas");
        System.out.println("- Press de banca");
        System.out.println("- Peso muerto");
        System.out.println("- Dominadas");
        System.out.println("- Curl de bíceps");
        System.out.println("- Extensiones de tríceps");
        System.out.println("- Crunches");
        System.out.println("- Plancha");
        System.out.println("-------------- Recuerda! debes hacer 3 series de 8-12 repeticiones cada una------");
    }

    public static void rutinaPushPullLegs(String dia) {
        if ("lunes".equals(dia) || "jueves".equals(dia)){
        System.out.println("Rutina Push Pull Legs:");
        System.out.println("Día Push:");
        System.out.println("- Press de banca");
        System.out.println("- Fondos en paralelas");
        System.out.println("- Press militar");
        System.out.println("- Extensiones de tríceps");
        System.out.println("- Elevaciones laterales");
    }
        else if("viernes".equals(dia) || "martes".equals(dia)){
        System.out.println("Día Pull:");
        System.out.println("- Dominadas");
        System.out.println("- Remo con barra");
        System.out.println("- Curl de bíceps");
        System.out.println("- Peso muerto rumano");
        System.out.println("- Encogimientos de hombros");
  
        }
        else if("domingo".equals(dia) || "sabado".equals(dia)){
        System.out.println("Día 3 - Legs:");
        System.out.println("- Sentadillas");
        System.out.println("- Prensa de piernas");
        System.out.println("- Zancadas");
        System.out.println("- Curl de piernas");
        System.out.println("- Elevaciones de gemelos");
        System.out.println("-------------- Recuerda! Realiza 3-4 series de 8-12 repeticiones para cada ejercicio ------");
    }}

    
    
    public static void rutinaTrenSuperiorInferior(String dia) {
        
       if ("lunes".equals(dia)){
        System.out.println("Rutina Tren Superior e Inferior para dos días:");
        System.out.println("Día 1-3 - Tren Superior:");
        System.out.println("- Press de banca");
        System.out.println("- Dominadas");
        System.out.println("- Press militar");
        System.out.println("- Remo con barra");
        System.out.println("- Curl de bíceps");
  
        System.out.println("- Extensiones de tríceps");
       }
       
      if ("martes".equals(dia)){
        System.out.println("Día 2-4 - Tren Inferior:");
        System.out.println("- Sentadillas");
        System.out.println("- Peso muerto");
        System.out.println("- Zancadas");
        System.out.println("- Curl de piernas");
        System.out.println("- Elevaciones de gemelos");
        System.out.println("-------------- Recuerda! Realiza 3-4 series de 8-12 repeticiones para cada ejercicio ------");
    }
    }
    public static boolean VasHoy(String coso) {
        boolean x;

        if (coso.equals("si")) {
            System.out.println("Hoy vas al gimnasio");
            x = true;
        } else {
            System.out.println("Hoy no vas al gimnasio");
            x = false;
        }

        return x;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Connection connection = null;

        try {
            // Establecer conexión
            String url = "jdbc:mysql://localhost:3306/sudoku";
            String usuario = "admin";
            String contraseña = "admin";
            connection = DriverManager.getConnection(url, usuario, contraseña);

            System.out.println("¡Conexión exitosa!");

            //registrar usuario
            Scanner scanner = new Scanner(System.in);
            String user;
            boolean usuarioExistente = false;
            boolean salir = false;

            while (!salir) {
                System.out.println("\n \n----- Menu -----");
                System.out.println("1. Iniciar sesión");
                System.out.println("2. Registrar usuario");
                System.out.println("3. Salir ");

                System.out.print("Seleccione una opción: ");
                int opcion = scanner.nextInt();
                if (opcion == 1) {
                    System.out.print("Ingrese el nombre de usuario: ");
                    scanner.nextLine(); // Limpiar el buffer del scanner
                    String username = scanner.nextLine();
                    System.out.print("Ingrese la contraseña: ");
                    String password = scanner.nextLine();

                    // Verificar el inicio de sesión en la base de datos
                    String sql = "SELECT * FROM gimnasio WHERE usuario = ? AND password = ?";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1, username);
                    statement.setString(2, password);
                    ResultSet resultSet = statement.executeQuery();

                    Calendar calendario = Calendar.getInstance();
                    int dia = calendario.get(Calendar.DAY_OF_WEEK);
                    System.out.print(dia);
                    String DiaSemana = null;
                    switch (dia) {
                        case 1:
                            DiaSemana = "domingo";
                            break;
                        case 2:
                            DiaSemana = "lunes";
                            break;
                        case 3:
                            DiaSemana = "martes";
                            break;
                        case 4:
                            DiaSemana = "miercoles";
                            break;
                        case 5:
                            DiaSemana = "jueves";
                            break;
                        case 6:
                            DiaSemana = "viernes";
                            break;
                        case 7:
                            DiaSemana = "sabado";

                            break;

                    }
                   

                    if (resultSet.next()) {
                        System.out.println("\n \n \n Inicio de sesión exitoso. ¡Bienvenido!");
                        String rutina = resultSet.getString("Rutina");
                        System.out.println("Tu rutina es: " + rutina);
                        System.out.println("Hoy es: " + DiaSemana);
                    
                        switch (dia) {
                            case 1:
                                DiaSemana = "domingo";
                                String domingo = resultSet.getString("domingo");
                                VasHoy(domingo);
                                if (VasHoy(domingo)==true){
                                Rutinacas(rutina,DiaSemana);
                                }
                                break;
                            case 2:
                                DiaSemana = "lunes";
                                String lunes = resultSet.getString("lunes");
                                VasHoy(lunes);
                                 
                                if (VasHoy(lunes)==true){
                                Rutinacas(rutina,DiaSemana);
                                }
                                break;
                            case 3:
                                DiaSemana = "martes";
                                String martes = resultSet.getString("martes");
                                VasHoy(martes);
                                if (VasHoy(martes)==true){
                                Rutinacas(rutina,DiaSemana);
                                }
                                break;
                            case 4:
                                DiaSemana = "miercoles";
                                String miercoles = resultSet.getString("miercoles");
                                VasHoy(miercoles);
                                if (VasHoy(miercoles)==true){
                                Rutinacas(rutina,DiaSemana);
                                }
                                break;
                            case 5:
                                DiaSemana = "jueves";
                                String jueves = resultSet.getString("jueves");
                                VasHoy(jueves);
                                if (VasHoy(jueves)==true){
                                Rutinacas(rutina,DiaSemana);
                                }
                                break;
                            case 6:
                                DiaSemana = "viernes";
                                String viernes = resultSet.getString("viernes");
                                VasHoy(viernes);
                                if (VasHoy(viernes)==true){
                                Rutinacas(rutina,DiaSemana);
                                }
                                break;
                            case 7:
                                DiaSemana = "sabado";
                                String sabado = resultSet.getString("sabado");
                                VasHoy(sabado);
                                if (VasHoy(sabado)==true){
                                Rutinacas(rutina,DiaSemana);
                                }

                                break;

                        }

                    } else {
                        System.out.println("Credenciales inválidas. Intente nuevamente.");
                    }

                    resultSet.close();
                    statement.close();

                } else if (opcion == 2) {
                    do {
                        System.out.println("Ingrese el nombre de usuario: ");
                        scanner.nextLine();
                        user = scanner.nextLine();

                        // Verificar si el usuario ya existe
                        String sql = "SELECT * FROM usuarios WHERE usuario = ?";
                        PreparedStatement statement = connection.prepareStatement(sql);
                        statement.setString(1, user);
                        ResultSet resultSet = statement.executeQuery();

                        if (resultSet.next()) {
                            System.out.println("El usuario ya existe. Intenta con otro nombre de usuario.");
                            usuarioExistente = true;
                        } else {
                            usuarioExistente = false;
                        }

                        resultSet.close();
                        statement.close();
                    } while (usuarioExistente);

                    System.out.print("Ingrese la contraseña: ");
                    String password = scanner.nextLine();
                    System.out.print("Ingrese el número: ");
                    String Dias = scanner.nextLine();
                    int numDias = Integer.parseInt(Dias);
                    String rutinaRecomendada;
                    if (numDias >= 1 && numDias <= 2) {
                        rutinaRecomendada = "Full body";
                    } else if (numDias >= 3 && numDias <= 4) {
                        rutinaRecomendada = "Tren Superior e inferior";
                    } else if (numDias >= 5 && numDias <= 6) {
                        rutinaRecomendada = "Push pull legs";
                    } else {
                        rutinaRecomendada = "Rutina no especificada";
                    }

                    System.out.println("La rutina que te recomendamos basado en el numero de dias es: " + rutinaRecomendada);
                    System.out.println("Selecciona los dias que vas a ir al gimnasio");
                    System.out.println("Escribe si o no");
                    System.out.print("Domingo:");
                    String domingo = scanner.nextLine();

                    System.out.print("lunes:");
                    String lunes = scanner.nextLine();
                    System.out.print("Martes:");
                    String martes = scanner.nextLine();
                    System.out.print("miercoles: ");
                    String miercoles = scanner.nextLine();
                    System.out.print("jueves: ");
                    String jueves = scanner.nextLine();
                    System.out.print("viernes: ");
                    String viernes = scanner.nextLine();
                    System.out.print("sabado: ");
                    String sabado = scanner.nextLine();
                    // Insertar el nuevo usuario en la base de datos
                    String sql = "INSERT INTO gimnasio (usuario, password, Dias, Rutina, domingo, lunes, martes, miercoles, jueves, viernes, sabado) VALUES (?, ?, ?, ?, ?,?,?,?,?,?,?)";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1, user);
                    statement.setString(2, password);
                    statement.setString(3, Dias);
                    statement.setString(4, rutinaRecomendada);
                    statement.setString(5, domingo);
                    statement.setString(6, lunes);
                    statement.setString(7, martes);
                    statement.setString(8, miercoles);
                    statement.setString(9, jueves);
                    statement.setString(10, viernes);
                    statement.setString(11, sabado);

                    int filasAfectadas = statement.executeUpdate();

                    if (filasAfectadas > 0) {
                        System.out.println("Usuario agregado correctamente.");
                    } else {
                        System.out.println("No se pudo agregar el usuario.");
                    }

                    statement.close();

                } else if (opcion == 3) {
                    System.out.print("Adiós");
                    salir = true;
                    break;

                } else {
                    System.out.print("Escoge de nuevo");
                }
            }

            scanner.close();
        } catch (SQLException e) {
            System.out.println("Error al conectarse a la base de datos: " + e.getMessage());
        } finally {
            // Cerrar la conexión
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    System.out.println("Error al cerrar la conexión: " + e.getMessage());
                }
            }
        }
    }

}
